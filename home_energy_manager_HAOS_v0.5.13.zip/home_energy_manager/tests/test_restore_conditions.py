"""Regression tests: real control_cycle, fake HA only; no physical devices."""
import copy
from datetime import datetime, timezone
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core import State
from settings import DEFAULT_CONFIG
from telemetry import Telemetry

class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.clock=1000000.0
        self.patcher=patch('core.time.time',side_effect=lambda:self.clock)
        self.patcher.start(); self.addCleanup(self.patcher.stop)
        self.s=State(Path(self.tmp.name))
        c=copy.deepcopy(DEFAULT_CONFIG)
        c.update(enabled=True,dry_run=False,restore_enabled=True,restore_hold_s=2,
                 min_off_s=0,restore_interval_s=1,settle_time_s=.1,
                 inverter_power_entity='sensor.inv',battery_power_entity='sensor.bat')
        c['devices']=[dict(id='a',name='First',switch_entity='switch.a',power_entity='sensor.a',grade=1,enabled=True,max_power_w=9500),
                      dict(id='b',name='Second',switch_entity='switch.b',power_entity='sensor.b',grade=3,enabled=True,max_power_w=9500)]
        self.s.config=c
        self.rows={}
        for d in c['devices']:
            self.rows[d['switch_entity']]={'entity_id':d['switch_entity'],'state':'off','last_changed':self.stamp(-400),'attributes':{}}
            self.rows[d['power_entity']]={'entity_id':d['power_entity'],'state':'0','attributes':{'unit_of_measurement':'W'}}
        for entity in ('sensor.inv','sensor.bat'):
            self.rows[entity]={'entity_id':entity,'state':'1000','attributes':{'unit_of_measurement':'W'}}
        self.commands=[]; self.fail=False
        def request(path,method='GET',data=None):
            if path=='states': return copy.deepcopy(list(self.rows.values()))
            if path.startswith('states/'): return copy.deepcopy(self.rows[path[7:]])
            if path.startswith('services/'):
                if self.fail: raise RuntimeError('simulated failure')
                switch=data['entity_id'];self.commands.append(switch)
                self.rows[switch].update(state='on' if path.endswith('turn_on') else 'off',last_changed=self.stamp())
                return []
            raise AssertionError(path)
        self.s.ha_request=request
        self.s.telemetry=Telemetry(request,self.s.stop)
    def stamp(self,offset=0): return datetime.fromtimestamp(self.clock+offset,timezone.utc).isoformat()
    def cycle(self,seconds=0,stale=False,battery_age=0):
        self.clock+=seconds
        for row in self.rows.values(): row['last_reported']=self.stamp(-100 if stale else 0)
        if battery_age is None:
            self.rows['sensor.bat'].pop('last_reported',None)
            self.rows['sensor.bat'].pop('last_updated',None)
        elif battery_age:
            self.rows['sensor.bat']['last_reported']=self.stamp(-battery_age)
        self.s.telemetry.poll(); self.s.control_cycle()
        return self.s.get_payload()['status']
    def reasons(self,status,index=0): return '；'.join(status['restore_queue'][index]['restore_wait_reasons'])
    def test_manual_closures_restore_all_despite_large_max_power(self):
        s=self.cycle();self.assertTrue(s['restore_queue'][0]['restore_countdown_active'])
        self.assertEqual(s['devices'][0]['rule_countdown_s'],2)
        self.cycle(2);self.assertEqual(self.commands,['switch.a'])
        self.cycle(1);self.cycle(2)
        self.assertEqual(self.commands,['switch.a','switch.b']);self.assertFalse(self.s.last_status['restore_queue'])
    def test_strict_threshold_equality_and_both_blockers(self):
        c=self.s.config
        self.rows['sensor.inv']['state']=str(c['restore_1_w'])
        self.rows['sensor.bat']['state']=str(c['battery_restore_1_w'])
        status=self.cycle();reason=self.reasons(status)
        self.assertIn('逆变器 6,500 W，需低于 6,500 W',reason)
        self.assertIn('电池放电 6,500 W，需低于 6,500 W',reason)
        self.assertFalse(status['devices'][0]['restore_countdown_active']);self.assertFalse(self.commands)
    def test_invalid_condition_restarts_hold(self):
        self.cycle();self.cycle(1)
        self.rows['sensor.bat']['state']='6500';self.cycle(.5)
        self.assertNotIn('restore',self.s._holds)
        self.rows['sensor.bat']['state']='1000'
        status=self.cycle(.5);self.assertEqual(status['devices'][0]['rule_countdown_s'],2)
        self.cycle(1);self.assertFalse(self.commands)
        self.cycle(1);self.assertEqual(self.commands,['switch.a'])
    def test_all_wait_times_and_queue_position_visible(self):
        self.s.config['min_off_s']=500
        self.s.runtime['last_restore']=self.clock
        status=self.cycle();reason=self.reasons(status)
        self.assertIn('最短断电剩余 100 秒',reason)
        self.assertIn('逐台恢复间隔剩余 1 秒',reason)
        self.assertIn('先恢复「First」',self.reasons(status,1))
    def test_stale_source_blocks(self):
        status=self.cycle(stale=True)
        self.assertIn('逆变器功率无效或报告过期',self.reasons(status))
        self.assertFalse(status['devices'][0]['restore_countdown_active']);self.assertFalse(self.commands)
    def test_disabled_and_simulated_modes_explained(self):
        for key in ('enabled','restore_enabled'):
            self.s.config[key]=False
            status=self.cycle();self.assertIn('未启用',self.reasons(status));self.s.config[key]=True
        self.s.config['dry_run']=True
        status=self.cycle();self.assertIn('模拟模式',self.reasons(status))
        self.cycle(3);self.assertFalse(self.commands)
    def test_fresh_reports_required_after_action(self):
        self.cycle();self.cycle(2)
        # Both reports still precede the settle deadline after first restore.
        status=self.cycle()
        self.assertIn('等待逆变器在上次操作稳定后重新报告功率',self.reasons(status))
        self.assertIn('等待操作稳定后重新读取电池实体',self.reasons(status))
    def test_failed_action_retries_and_explains_cooldown(self):
        self.fail=True;self.cycle();status=self.cycle(2)
        self.assertIn('操作失败重试冷却剩余 30 秒',self.reasons(status))
        self.fail=False;self.cycle(30);self.cycle(2)
        self.assertEqual(self.commands,['switch.a'])
    def test_zero_max_does_not_block(self):
        self.s.config['devices'][0]['max_power_w']=0
        self.cycle();self.cycle(2);self.assertEqual(self.commands,['switch.a'])
    def test_shedding_and_rated_limit_explained(self):
        self.rows['switch.b']['state']='on'
        self.rows['sensor.inv']['state']='10000';self.s.config['dry_run']=True
        status=self.cycle();self.assertIn('正在优先处理减载',self.reasons(status))
        self.assertIn('达到额定上限',self.reasons(status))

    def test_old_zero_battery_restores_entire_queue(self):
        self.rows['sensor.bat']['state']='0'
        status=self.cycle(battery_age=86400)
        self.assertTrue(status['display']['sources']['battery']['control_valid'])
        self.assertFalse(status['display']['sources']['battery']['last_value'])
        self.assertTrue(status['devices'][0]['restore_countdown_active'])
        self.cycle(2,battery_age=86400); self.cycle(1,battery_age=86400); self.cycle(2,battery_age=86400)
        self.assertEqual(self.commands,['switch.a','switch.b'])
    def test_zero_without_report_time_is_valid(self):
        self.rows['sensor.bat']['state']='0.0'
        status=self.cycle(battery_age=None)
        self.assertTrue(status['display']['sources']['battery']['control_valid'])
        self.cycle(2,battery_age=None)
        self.assertEqual(self.commands,['switch.a'])
    def test_unchanged_positive_battery_is_valid_but_threshold_still_applies(self):
        self.rows['sensor.bat']['state']='6600'
        status=self.cycle(battery_age=86400)
        self.assertIn('电池放电 6,600 W，需低于 6,500 W',self.reasons(status))
        self.assertTrue(status['display']['sources']['battery']['control_valid'])
        self.assertFalse(status['devices'][0]['restore_countdown_active'])
    def test_invalid_battery_never_uses_last_zero_for_control(self):
        self.rows['sensor.bat']['state']='0';self.cycle()
        for value in ('unavailable','unknown','NaN','inf','invalid'):
            with self.subTest(value=value):
                self.rows['sensor.bat']['state']=value
                status=self.cycle(3,battery_age=86400)
                self.assertIn('电池实体不可用或无有效功率数值',self.reasons(status))
                self.assertFalse(status['display']['sources']['battery']['control_valid'])
                self.assertFalse(status['devices'][0]['restore_countdown_active'])
                self.assertFalse(self.commands)
    def test_old_signed_kw_battery_respects_direction(self):
        self.rows['sensor.bat'].update(state='-0.5',attributes={'unit_of_measurement':'kW'})
        self.s.config['battery_discharge_direction']='negative'
        status=self.cycle(battery_age=86400)
        self.assertEqual(status['battery_power_w'],500)
        self.assertEqual(status['display']['sources']['battery']['power_w'],500)
    def test_transport_failure_still_blocks_recovery(self):
        self.rows['sensor.bat']['state']='0';self.cycle(battery_age=86400)
        self.s.telemetry._online=False
        self.clock+=3;self.s.control_cycle()
        self.assertEqual(self.s.last_status['state'],'api_error');self.assertFalse(self.commands)
    def test_battery_post_action_uses_actual_poll_time(self):
        self.cycle();self.cycle(2)
        rows=self.s.telemetry.control_states()
        observed=next(r['_ha_observed_at'] for r in rows if r['entity_id']=='sensor.bat')
        self.clock+=2
        self.assertFalse(self.s._fresh_after_action(self.s.config,{'inverter':self.clock,'battery':observed},['inverter','battery']))
        self.cycle(battery_age=86400)
        self.assertTrue(self.s.last_status['restore_queue'][0]['restore_countdown_active'])

if __name__=='__main__': unittest.main(verbosity=2)
